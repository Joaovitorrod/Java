package pacote;

import static java.lang.System.out;

/**
 * Comentar sobre o Programa.
 */
public class Programa { //OMG, this is horrible, Bob is an  !!!
  /**
   * Comentar sobre o main.
   */
  public static void main(String[] args) {
    out.println("Dale");
  }
}
